<template>
  <div class="container">
    <div v-title data-title="拼团详情">拼团详情</div>
    <pr-header :text="title" :sw="sw"></pr-header>
    <div class="goods_info">
      <div class="goods_info_detail">
        <div class="goods_info_detail_image">
          <img v-if="groupInfo.images" :src="URL + groupInfo.images" alt="">
        </div>
        <div class="goods_info_detail_desc">
          <div class="goods_info_detail_desc_name">
            {{groupInfo.title}}
          </div>
          <div class="goods_info_detail_desc_price">
            <div class="goods_info_detail_desc_price_tuan">
              <div class="goods_info_detail_desc_price_tuan_tag" v-if="groupInfo.group_person_num">
                {{groupInfo.group_person_num}}人拼
              </div>
              <div v-if="groupInfo.price_sum" class="goods_info_detail_desc_price_tuan_pgprice">￥<span class="goods_info_detail_desc_price_tuan_pgprice_int">{{groupInfo.price_sum.substring(0,groupInfo.price_sum.length-3)}}</span>{{groupInfo.price_sum.substring(groupInfo.price_sum.length-3,groupInfo.price_sum.length)}}</div>
            </div>
            <div class="goods_info_detail_desc_price_old">单价买<span class="goods_info_detail_desc_price_old_price">{{groupInfo.price_market}}</span></div>
          </div>
        </div>
      </div>
    </div>
    <div class="tuan_qc">
      <div class="tuan_status" v-if="orderStatus.group_status == 2 || orderStatus.group_status == 3">
          <div class="succeed" v-if="orderStatus.group_status == 2">恭喜您拼购成功</div>
          <div v-if="orderStatus.group_status == 3">该团未能按时凑齐人数，拼购失败</div>
      </div>
      <div class="tuan_status_tips" v-else>
        还差<span class="tuan_status_tips_num">{{chaNum}}人</span>拼购成功，剩余
        <span class="tuan_countdown">
                                          <span class="countdown_time">{{hour}}</span>:<span class="countdown_time">{{Minute}}</span>:<span class="countdown_time">{{second}}</span>
        </span>
      </div>
      <div class="tuan_status_btns">
        <button class="tuan_status_btns_btn" @click="cantuan" v-if="orderStatus.group_status == 1&&isUser.is_user == 0">我要参团</button>
        <button class="tuan_status_btns_btn disabled_btn" v-if="isUser.is_user == 2">您的拼团未结束</button>
        <button class="tuan_status_btns_btn" v-if="orderStatus.group_status == 1 &&isUser.is_user == 1" @click="toShare">邀请好友</button>
      </div>
    </div>
    <div class="tuan_member_list">
      <div class="tuan_title">参团记录</div>
      <div class="tuan_member_item" v-for="(item,index) in tuanInfo" :key="index">
        <img class="tuan_member_image" :src="URL + item.user_header" alt="">
        <div class="tuan_member_info">
          <div class="member_name">
            {{item.nick_name}}
            <span v-if="index==0" class="tag_member">团长大人</span>
          </div>
          <p class="tuan_time"><span>{{tuanTime(item.pay_time)}} </span> <span v-if="index==0">开团</span><span v-else>参团</span></p>
        </div>
      </div>
    </div>
    <div class="tuan_btn" v-if="orderStatus.group_status == 3">
      <router-link to="groupList">查看更多活动商品</router-link>
    </div>
    <div class="load-wrap" v-show="load_wrap" @touchmove.prevent>
      <mt-spinner type="triple-bounce" color="rgb(38, 162, 255)"></mt-spinner>
    </div>
    <!-- 弹框的html -->
    <div id="picture" class="mui-popover mui-popover-action mui-popover-bottom" style="z-index: 99999999">
      <ul class="mui-table-view">
        <li class="mui-table-view-cell">
          <a href="javascript:;" id="saveImg">保存图片</a>
        </li>
      </ul>
      <ul class="mui-table-view">
        <li class="mui-table-view-cell">
          <a href="#picture"><b>取消</b></a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  import PrHeader from './children/shop_header.vue';
  import {
    MessageBox,Toast
  } from 'mint-ui';
  import qs from 'qs';
  export default {
    name: 'groupDetail',
    data() {
      return {
        sw: 1,
        detailData: [],
        title: '拼团详情',
        isUser:'',
        load_wrap: true,
        price: '9.90',
        hour: '00',
        Minute: '00',
        second: '00',
        tuanInfo: {},
        groupInfo: {},
        chaNum: 0,
        orderStatus: ''
      }
    },
    created() {
        if (this.$route.query.s) {
            this.groupDetailOne();
        } else {
            this.groupDetail();
        }
    },
    mounted() {
      document.body.scrollTop = 0;
    },
    methods: {
      //参团
      cantuan(){
          this.$router.push({
              path:'/groupConfirmOrder',
              query:{
                  goods_id:this.groupInfo.goods_id,
                  group_id:this.groupInfo.group_id,
                  send_address:0,
                  price:this.groupInfo.price_sum,

                  order_id:this.groupInfo.id
              }
          })
      },
      //日期处理
      dateProcessing(m) {
        return m < 10 ? '0' + m : m;
      },
      tuanTime(stamp) {
        let time = new Date(stamp * 1000);
        let y = time.getFullYear();
        let m = time.getMonth() + 1;
        let d = time.getDate();
        let h = time.getHours();
        let mm = time.getMinutes();
        let s = time.getSeconds();
        return y + '-' + this.dateProcessing(m) + '-' + this.dateProcessing(d) + ' ' + this.dateProcessing(h) + ':' + this.dateProcessing(mm) + ':' + this.dateProcessing(s);
      },
      //获取拼团详情
      groupDetail() {
        if (!sessionStorage.getItem('user_ID')) {
          sessionStorage.setItem('groupRouteInfo', JSON.stringify(this.$route.query));
          this.$router.push('LogoIn');
        } else {
          this.axios.post(API_URL + 'Home/Group/joinGroup', qs.stringify({
            id: this.$route.query.id,
            // group_id: this.$route.query.group_id,
            app_user_id: sessionStorage.getItem('user_ID')
          })).then((res) => {
            if(res.data.status == 1){
                this.orderStatus = res.data.data.orderStatus;
                this.isUser = res.data.data.isUser;
                console.log(this.isUser);
                this.tuanInfo = res.data.data.userData;
                this.groupInfo = res.data.data.goodsData;
                this.chaNum = this.groupInfo.group_person_num - this.groupInfo.buy_num;
                this.processingTime();
            }else{
                Toast({
                    message: res.data.msg,
                    position: 'middle',
                    duration: 1500
                });
            }
            this.load_wrap = false;
          }).catch((err) => {
            console.log(err);
          });
        }
  
      },
        groupDetailOne() {
            if (!sessionStorage.getItem('user_ID')) {
                this.$router.push('LogoIn');
            } else {
                this.axios.post(API_URL + 'Home/Group/joinGroupOne', qs.stringify({
                    id: this.$route.query.id,
                    group_id: this.$route.query.group_id,
                    app_user_id: sessionStorage.getItem('user_ID')
                })).then((res) => {
                    this.orderStatus = res.data.data.orderStatus;
                    this.tuanInfo = res.data.data.userData;
                    this.groupInfo = res.data.data.goodsData;
                    this.chaNum = this.groupInfo.group_person_num - this.groupInfo.buy_num;
                    this.processingTime();
                    this.load_wrap = false;
                }).catch((err) => {
                    console.log(err);
                });
            }
        },
      //分享二维码
      toShare(item) {
        this.axios({
          url: API_URL + 'Home/Group/getSharePicture',
          method: 'get',
          params: {
            app_user_id: sessionStorage.getItem('user_ID'),
            id: this.groupInfo.id,
            group_id: this.groupInfo.group_id
          }
        }).then((res) => {
          MessageBox({
            title: '',
            showConfirmButton: false,
            cancelButtonClass: false,
            message: '<p id="imgsul"><img class="saveImg" style="width:4.5rem; height:6.75rem;margin-bottom:.3rem;" src=' + this.URL + res.data.data + '></p><p>长按保存，分享好友</p>',
          })
          this.publicMethod.savePictures();
  
        }).catch((err) => {
          console.log(err);
        });
      },
      //处理倒计时
      processingTime() {
        let self = this;
        let now_Time = this.groupInfo.time;
        let end_Time = this.groupInfo.overdue_time;
        let timer = setInterval(function() {
          let t = 0;
          let now = new Date(now_Time * 1000);
          let end = new Date(end_Time * 1000);
          t = end.getTime() - now.getTime();
          if (t > 0) {
            let hour = Math.floor(t / 3600000);
            let min = Math.floor((t / 60000) % 60);
            let sec = Math.floor((t / 1000) % 60);
            hour = hour < 10 ? "0" + hour : hour;
            min = min < 10 ? "0" + min : min;
            sec = sec < 10 ? "0" + sec : sec;
            self.hour = `${hour}`;
            self.Minute = `${min}`;
            self.second = `${sec}`;
          } else {
            clearInterval(timer);
            self.hour = `00`;
            self.Minute = `00`;
            self.second = `00`;
          }
          now_Time += 1;
        }, 1000);
      },
    },
    components: {
      PrHeader
    }
  }
</script>

<style lang="less" scoped>
  #picture{
    display: none;
  }
  .container {
    background: #fff;
    .goods_info {
      margin: .2rem;
      background-color: #fff;
      overflow: hidden;
      border: 1px solid #e5e5e5;
      border-radius: 2px;
      position: relative;
      .goods_info_detail {
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;
        padding: .3rem;
        .goods_info_detail_image {
          display: inline-block;
          overflow: hidden;
          width: 2.3rem;
          height: 2.3rem;
          img {
            width: 100%;
            height: 100%;
          }
        }
        .goods_info_detail_desc {
          -webkit-box-flex: 1;
          -webkit-flex: 1;
          flex: 1;
          margin-left: .3rem;
          position: relative;
          .goods_info_detail_desc_name {
            font-size: .28rem;
            overflow: hidden;
            text-overflow: ellipsis;
            word-break: break-all;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
          }
          .goods_info_detail_desc_price {
            position: absolute;
            bottom: 0;
            .goods_info_detail_desc_price_tuan {
              color: #ed3851;
              .goods_info_detail_desc_price_tuan_tag {
                position: relative;
                display: inline-block;
                height: .3rem;
                padding: 0 .04rem 0 .34rem;
                line-height: .3rem;
                font-size: .24rem;
                border-radius: 2px;
                border: 1px solid #ed3851;
                vertical-align: baseline;
              }
              .goods_info_detail_desc_price_tuan_tag:before {
                content: "";
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                width: .28rem;
                background: url(../../assets/tx_icon.png)no-repeat #e93b3d;
                background-size: 70% 70%;
                background-position: 50% 50%;
              }
              .goods_info_detail_desc_price_tuan_pgprice {
                margin-left: .1rem;
                font-size: .32rem;
                line-height: .52rem;
                display: inline-block;
                .goods_info_detail_desc_price_tuan_pgprice_int {
                  font-size: .48rem;
                }
              }
            }
            .goods_info_detail_desc_price_old {
              color: #999;
              margin-top: .1rem;
              font-size: .24rem;
              .goods_info_detail_desc_price_old_price {
                margin-left: .24rem;
                text-decoration: line-through;
              }
            }
          }
        }
      }
    }
    .tuan_qc {
        .tuan_status {
          padding: .2rem 0;
          div {
            line-height: .56rem;
            text-align: center;
            color: #333;
            font-size: .32rem;
            font-weight: 700;
          }
          .succeed:before {
            content: "";
            display: inline-block;
            vertical-align: middle;
            width: .6rem;
            height: .6rem;
            margin: -.04rem .1rem 0 0;
            background-image: url(../../assets/57274242.png);
            background-size: 100%;
          }
        }
      .tuan_status_tips {
        position: relative;
        text-align: center;
        height: .42rem;
        line-height: .42rem;
        margin: .4rem auto;
        color: #333;
        font-size: .28rem;
        .tuan_status_tips_num {
          color: #ff574e;
        }
        .tuan_countdown {
          color: #ff574e;
          .countdown_time {
            width: .38rem;
            height: .42rem;
            border-radius: 6px;
            margin: 0 .03rem;
            display: inline-block;
            color: #fff;
            background-color: #ff574e;
          }
        }
      }
      .tuan_status_btns {
        display: -webkit-box;
        display: -webkit-flex;
        display: flex;
        padding: 0 .2rem;
        margin-bottom: .2rem;
        .tuan_status_btns_btn {
          color: #fff;
          background-color: #ff574e;
          border: 0!important;
          height: .9rem;
          line-height: .9rem;
          font-size: .32rem;
          -webkit-box-flex: 1;
          -webkit-flex: 1;
          flex: 1;
          border-radius: 4px;
        }
        .disabled_btn{
          background-color: #ccc;
        }
      }
    }
    .tuan_member_list {
      padding-left: .2rem;
      padding-bottom: 1rem;
      .tuan_title {
        padding: .3rem 0 .2rem;
        color: #c9c9c9;
        font-size: .24rem;
      }
      .tuan_member_item {
        padding: .2rem .2rem .2rem 0;
        .tuan_member_image {
          width: .8rem;
          height: .8rem;
          border-radius: 40px;
          float: left;
        }
        .tuan_member_info {
          margin-left: .96rem;
          font-size: .24rem;
          .member_name {
            line-height: .44rem;
            .tag_member {
              margin-left: .06rem;
              padding: .04rem;
              color: #fff;
              border: 1px solid #e5e5e5;
              border-radius: 3px;
              font-size: .24rem;
              line-height: .24rem;
              background-color: #ff574e;
              border-color: #ff574e;
              display: inline-block;
            }
          }
          .tuan_time {
            font-size: .24rem;
            line-height: .32rem;
            white-space: nowrap;
            margin: 0 0 .04rem;
            color: #ccc;
          }
        }
      }
    }
    .tuan_btn {
      display: -webkit-box;
      display: -webkit-flex;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: .8rem;
      z-index: 100;
      position: fixed;
      left: 0;
      bottom: 0;
      background-color: #fff;
      a {
        color: #fff;
        background-color: #ed5050;
        border-color: #ed5050;
        border-radius: 3px;
        padding: .13rem .6rem;
        font-size: .28rem;
      }
    }
  }
</style>