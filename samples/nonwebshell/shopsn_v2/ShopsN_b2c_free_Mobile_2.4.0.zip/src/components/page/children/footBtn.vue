<template>
    <div class="footer2017">
        <div class="swiper" v-show="$route.name === 'groupProduct' && tuanInfo ">
            <div class="swiper-container">
                <div class="swiper-wrapper" >
                    <div class="swiper-slide" v-for="(item, index) in tuanInfo" :key="index" style="height: 1rem;">
                        <div class="tuan_recommend" @click="grouCheck(item)" >
                            <div class="ava">
                                <img :src="!item.pic_url ? '../../../static/default.png' : URL + item.pic_url" alt="">
                            </div>
                            <div class="right">
                                <div class="info">
                                    <span>{{item.nick_name}}的团</span>
                                    <i>只差{{item.lack_person}}人</i>
                                </div>
                            </div>
                            <div class="guide">去拼单</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="seat"></div>
        <div class="btn-main clearfix" v-if="$route.params.status == 1">
            <div class="col fl" @click="col"><em>{{icon}}</em>收藏</div>
            <div class="join fl" @click="hide">加入购物车</div>
            <div class="imm fl" @click="hide">立即购买</div>
        </div>
        <div class="btn-main  clearfix" v-else-if="$route.params.status == 2">
            <!--<span class="fl ex">我的积分：<em>1000</em>积分</span>-->
            <div class="imm fr" @click="hide">立即兑换</div>
        </div>
        <div class="btn-main border clearfix" v-else>
            <div class="item" >

                <div v-if="state" @click="toGroupOrder" class="imm fr">{{$store.state.buy_text_status}}</div>
                <div class="com fr" v-if="price">
                    <div class="text-single-hidden" style="margin-right: .2rem">
                        <span> {{$store.state.commodity_val}} </span>件&nbsp;&nbsp; 共
                        <span v-if="state"><i>￥</i>{{price.price}}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import { Toast } from 'mint-ui';
    import qs from 'qs';
    import Swiper from 'swiper'
    export default {
        name : 'footBtn',
        data(){
            return {
                icon : '☆',
                type:''
            }
        },
        props:{
            data:'',
            nb:'',
            text: '',
            state: '',
            price:'',
            tuanInfo: ''
        },
        watch: {
            tuanInfo () {
                this.$nextTick(() => {
                    new Swiper(".swiper-container", {
                        autoplay: {
                            delay:2000
                        },
                        direction:"vertical",
                        loop: true

                    });
                })
            }
        },
        created(){
            console.log(this.$route.name)
           console.log(this.tuanInfo)
        },
        methods:{
            col(){//收藏
                if(this.icon == '☆'){
                    this.icon = '★';
                    this.type = 1;
                }else{
                    this.icon = '☆';
                    this.type = 2;
                }
                this.axios.post(API_URL + 'Home/Cart/add_collection',qs.stringify({
                    app_user_id:sessionStorage.getItem('user_ID'),
                    goods_id:this.$route.params.id,
                    type:this.type
                })).then((res) => {
                    if(res.data.msg === '已取消'){
                        this.msg = '取消收藏成功！';
                    }else{
                        this.msg = '恭喜，宝贝收藏成功！';
                    }
                    Toast({
                        message: this.msg,
                        position: 'bottom',
                        duration: 800
                    });
                }).catch((err) => {
                    console.log(err);
                })
            },
            grouCheck(item) {

                if (!sessionStorage.getItem('user_ID')) {
                    this.$router.push('LogoIn');
                } else {
                    this.$router.push({
                        path:'/groupDetail',
                        query:{
                            id:item.id,
                            group_id:item.group_id
                        }
                    })
                }
            },
            hide(){
                this.$store.state.const_join = true;
            },
            toGroupOrder(){
                if (!sessionStorage.getItem('user_ID')) {
                    this.$router.push('/LogoIn');
                    return;
                }else if(this.price.goods_num == 0){
                    Toast({
                        message: '库存不足',
                        position: 'middle',
                        duration: 800
                    });
                    return false;
                };
                this.$router.push({
                    path:'/groupConfirmOrder',
                    query:{
                        goods_id:this.price.goods_id,
                        group_id:this.price.id,
                        send_address:this.price.send_address,
                        price:this.price.price
                    }
                })
            },
        }
    }
</script>
<style lang="less" scoped>
    .swiper {
        width: 100%;
        height: 2rem;
        overflow: hidden;
        background: white;
        img {
            width: .5rem;
            height: .5rem;

        }
    }
    .swiper-wrapper {
        width: 100%;
        height: 50%;
        flex-direction: column;
    }
    .swiper-container {
        width: 100%;
        height: 50%;
    }
    .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;
        height: 1rem;
        /* Center slide text vertically */
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
    }
    .footer2017{
        width: 100%;
        position: fixed;
        bottom: 0;
        left: 0;
        display: flex;
        flex-direction: column;
        width:100%;
        .tuan_recommend {
            position: relative;
            background-color: #fcf6ed;
            height: 1rem;
            line-height: 1rem;
            color: #de8c17;
            font-size: .2rem;
            display: flex;
            align-items: center;
            flex: 1;
            .right {
                display: flex;
            }
            div {
                display: flex;
            }
            .ava {
                position: relative;
                display: inline-block;
                width: .6rem;
                height: .6rem;
                padding: .2rem;
                margin-right: .3rem;
                img {
                    position: absolute;
                    width: .6rem;
                    height: .6rem;
                    border-radius: 50%;
                    box-sizing: border-box;
                }
            }
            .info {
                display: inline;
                font-size: .28rem;
                color: #666;
                span {
                    display: inline-block;
                    vertical-align: bottom;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    max-width: 1.7rem;
                    font-size: .28rem;
                }
                i {
                    color: #de8c17;
                    font-style: normal;
                    font-size: .28rem;
                }
            }
            .guide {
                position: absolute;
                right: .2rem;
                height: .53rem;
                width: 1.07rem;
                display: flex;
                justify-content: center;
                align-items: center;
                background: #ff0000;
                color:#fff;
            }
        }
        .ex{
            font-size:.22rem;
            color:#999;
            padding-left:.2rem;
            line-height: .9rem;
            em{
                font-style:normal;
                font-size:.32rem;
                color:#d0111b;
            }
        }
        .seat{
            width:100%;
            height:100%;
            background:#f1f1f1;
        }
        .border{
            border:1px solid #dfdfdf;
        }
        .btn-main{
            width:100%;
            height:1rem;
            text-align:center;
            background:#fff;
            .item{
                .com {
                    height: 1rem;
                    line-height: 1rem;
                    text-align: right;
                    font-size: .3rem;
                    color: #666;
                    span {
                        font-size: .32rem;
                        color: #ff7200;
                        font-weight: bold;
                        i {
                            font-size: .32rem;
                            font-style: normal;
                        }
                    }
                }
            }
            .col{
                width:2.4rem;
                height:100%;
                color:#333;
                font-size:.22rem;
                position:relative;
                line-height:1.5rem;
                position:relative;
                em{
                    width:.5rem;
                    height:.5rem;
                    position:absolute;
                    top:.1rem;
                    left:50%;
                    margin-left:-.25rem;
                    font-style:normal;
                    color:#d21923;
                    font-size:.5rem;
                    line-height:100%;
                }
            }
            .join{
                width:2.5rem;
                height:100%;
                background:#ff7200;
                color:#fff;
                font-size:.32rem;
                line-height:1rem;
            }
            .imm{
                width:2.5rem;
                height:100%;
                background:#d0111b;
                color:#fff;
                font-size:.32rem;
                line-height:1rem;
            }
        }
    }
</style>
<style lang="less">
    .mint-toast{
        .mint-toast-text{
            font-size:.3rem;
        }
    }
</style>