<template>
    <div class="order-wrap">
        <div v-title data-title="确认订单">确认订单</div>
        <order-header :text="title" :btn="btn"></order-header>
        <div class="inf-header" @click="tolink('address')">
            <div v-if="rec_address">
                <div class="inf-name clearfix">
                    <div class="name fl"><span></span>{{rec_address.realname}}</div>
                    <div class="phone fr"><span></span>{{rec_address.mobile}}</div>
                </div>
                <div class="address">{{rec_address.prov+rec_address.city+rec_address.dist+rec_address.address}}</div>
            </div>
            <div class="status text-center" v-if="!rec_address">您还没有填写收货地址，请填写！</div>
            <span class="btn-right"></span>
        </div>
        <div class="bottom-bg"><img src="../../assets/bottom-bj.jpg"></div>
        <ul v-if="data" class="mark-wrap" v-for="(address,index) in send_address" :key="address.id">
            <p class="send_address">{{address.stock_name}}</p>
            <li class="clearfix" v-if="address.id == item.send_address" v-for="(item,index) in data.goods" :key="item.id">
                <img :src="URL + item.fatherImg" class="fl">
                <div class="pull-right fl">
                    <p class="text">{{item.title}}</p>
                    <p class="price-wrap clearfix">
                        <span class="fl price">￥<span>{{item.price_member}}</span></span>
                        <span class="number fr">x{{item.num}}</span>
                    </p>
                </div>
            </li>
        </ul>
        <div v-if="data" class="dist-wrap">
            <div class="hd active clearfix">
                <div class="title fl">配送方式</div>
                <div class="busi fr">自选快递</div>
            </div>
            <!--<div v-if="couponsList.length != 0" class="hd active clearfix" @click="openLayer">-->
            <!--<div class="title fl">优惠券</div>-->
            <!--<div v-if="!selectionCouponInfo.text" class="busi fr">-->
            <!--<span v-if="selectionCouponInfo.reduced_type == 1">-->
            <!--省{{selectionCouponInfo.money|keepTwoNum}}元:{{selectionCouponInfo.condition}}减{{selectionCouponInfo.money}}-->
            <!--</span>-->
            <!--<span v-else>-->
            <!--省{{selectionCouponInfo.money|keepTwoNum}}元:{{selectionCouponInfo.condition}} {{selectionCouponInfo.discount}}折-->
            <!--</span>-->
            <!--</div>-->
            <!--<div v-else class="busi fr">{{selectionCouponInfo.text}}</div>-->
    
            <!--</div>-->
            <div class="dd">
                <div class="title">给商家留言：</div>
                <textarea placeholder="选填：备注限字在45个字以内" contenteditable="true" v-model="message"></textarea>
                <p class="ind">共<span v-if="data.goods">{{data.goods.length}}</span>件商品</p>
            </div>
        </div>
        <div v-if="data" class="price-set-wrap">
            <div class="total price clearfix">
                <span class="fl">商品总额</span>
                <span class="fr price_color">￥{{data.total_price|keepTwoNum}}</span>
            </div>
            <!--<div class="curInt price clearfix">-->
            <!--<span class="fl">自购返利</span>-->
            <!--<span class="fr price_color">￥{{data.rebate|keepTwoNum}}</span>-->
            <!--</div>-->
            <div class="freight price clearfix">
                <span class="fl">运费</span>
                <span class="fr price_color">+<i>￥{{freight|keepTwoNum}}</i></span>
            </div>
        </div>
        <div v-if="data" class="footer-wrap">
            <div class="foot-seat"></div>
            <div class="footer clearfix">
                <button class="fr btn" :disabled="status" @click="toCashier">提交订单</button>
                <div class="fr money">实付款&nbsp;:&nbsp;<span class="price">￥<span>{{(Number(data.total_price) + Number(freight)) |keepTwoNum}}</span></span>
                </div>
            </div>
        </div>
        <Shopsn></Shopsn>
        <div class="load" v-show="load" @touchmove.prevent>
            <mt-spinner type="triple-bounce" color="rgb(38, 162, 255)"></mt-spinner>
        </div>
        <div class="load-wrap" v-show="load_wrap" @touchmove.prevent>
            <mt-spinner type="triple-bounce" color="rgb(38, 162, 255)"></mt-spinner>
        </div>
    </div>
</template>

<script>
    import orderHeader from './children/header.vue';
    import {
        Toast
    } from 'mint-ui';
    import Shopsn from '@/components/page/Shopsn.vue';
    import qs from 'qs';
    export default {
        name: 'groupConfirm',
        data() {
            return {
                showAble: true,
                title: '确认订单',
                btn: '', //头部客服按钮开关
                data: '',
                scrollWatch: true,
                coupon: '请选择优惠券',
                invoice_type: '无需发票', //发票选择
                rec_address: '',
                address_id: '',
                load: false,
                load_wrap: true,
                message: '', //留言
                invoice_status: 0,
                status: false,
                gcheck: 0,
                send_address: [],
                freight: 0,
                goodsData: ''
            }
        },
        created() {
            sessionStorage.removeItem('groupInfo');
            this.getData();
            this.axios.post(API_URL + 'Home/Group/getcheck', qs.stringify({
                app_user_id: sessionStorage.getItem('user_ID'),
            })).then((res) => {
                if (res.data.status == 1) {
                    this.gcheck = res.data.data;
                }
            }).catch((err) => {
                console.log(err);
            });
        },
        methods: {
            // getCouponsList() { //获取可使用的优惠券
            //     let totalPrice = this.data.total_price;
            //     let goodsList = [];
            //     for (let index = 0; index < this.data.goods.length; index++) {
            //         goodsList.push(this.data.goods[index].id);
            //     }
            //     this.axios.post(API_URL + 'Home/Coupon/getUsableCoupons', qs.stringify({
            //         app_user_id: sessionStorage.getItem('user_ID'),
            //         sum: totalPrice,
            //         goods_id: goodsList.join(',')
            //     })).then((res) => {
            //         this.load_wrap = false;
            //         if (res.data.status == 1) {
            //             let data = res.data.data;
            //             for (let index = 0; index < data.length; index++) {
            //                 data[index].isSelect = false;
            //                 data[index].condition = data[index].condition.substring(0, data[index].condition.length - 3);
            //                 data[index].money = data[index].money.substring(0, data[index].money.length - 3);
            //             }
            //             this.$set(data[0], 'isSelect', true); //默认第一个选中
            //             if (data[0].reduced_type == 2) { //是折扣券 手动计算
            //                 this.$set(data[0], 'money', parseFloat(this.data.total_price) - (parseFloat(this.data.total_price) * parseFloat(data[0].discount) / 100));
            //             }
            //             this.selectionCouponInfo = data[0]; //默认第一个优惠力度大
            //             this.couponsList = data;
            //         }
            //     }).catch((err) => {
            //         console.log(err);
            //     });
    
            // },
            // selectCoupon(item, index) { //选择优惠券
            //     for (let i = 0; i < this.couponsList.length; i++) {
            //         if (index == i) {
            //             if (this.couponsList[i].isSelect == false) {
            //                 this.$set(this.couponsList[i], 'isSelect', true);
            //                 if (this.couponsList[i].reduced_type == 2) { //选中打折券时
            //                     this.$set(this.couponsList[i], 'money', this.data.total_price - (this.data.total_price * (this.couponsList[i].discount / 100)));
            //                 }
            //                 this.selectionCouponInfo = item;
            //             } else {
            //                 this.$set(this.couponsList[i], 'isSelect', false);
            //                 this.selectionCouponInfo = {
            //                     text: '不使用优惠券',
            //                     money: 0,
            //                     id: ''
            //                 };
            //             }
            //         } else {
            //             this.$set(this.couponsList[i], 'isSelect', false);
            //         }
            //
            //     }
            // },
            getFreight() {
                this.axios.post(API_URL + 'Home/Group/sumFreight2', qs.stringify({
                    app_user_id: sessionStorage.getItem('user_ID'),
                    addressId: this.address_id
                })).then((res) => {
                    this.freight = res.data.data.money;
                }).catch((err) => {
                    console.log(err);
                });
            },
            //选取地址
            selectAddress() {
                this.rec_address = JSON.parse(sessionStorage.getItem('set_address'));
                this.address_id = this.rec_address.id;
            },
            getData() {
                if (sessionStorage.getItem('user_ID')) { //团购商品
                    let obj = this.$route.query;
                    this.goodsData = [{
                        num: 1,
                        id: obj.goods_id,
                        goods_price: obj.price,
                        send_address: obj.send_address,
                    }];
                    this.axios.post(API_URL + 'Home/Group/buyGroup', qs.stringify({
                        app_user_id: sessionStorage.getItem('user_ID'),
                        order_id: obj.order_id,
                        group_id: obj.group_id,
                        goods: JSON.stringify(this.goodsData)
                    })).then((res) => {
                        if (res.data.status) {
                            this.data = res.data.data;
                            this.send_address = res.data.data.send_address;
                            if (res.data.data.address) {
                                this.rec_address = res.data.data.address;
                                this.address_id = res.data.data.address.id;
                            } else {
                                this.selectAddress()
                            }
                            if (res.data.data && sessionStorage.getItem('set_address')) {
                                this.selectAddress()
                            }
                            this.getFreight();
                        } else {
                            Toast({
                                message: res.data.msg,
                                position: 'middle',
                                duration: 2000
                            });
                        }
                        this.load_wrap = false;
                    }).catch((err) => {
                        console.log(err);
                    });
                } else {
                    this.$router.push('/LogoIn');
                };
            },
            toCashier() {
                //商品订单生成
                if (this.status == false) {
                    this.status = true;
                    if (!this.rec_address.id) {
                        Toast('请完善收货地址');
                        this.$router.push('/address');
                    }
                    this.axios.post(API_URL + 'Home/Group/orderBegin', qs.stringify({
                        app_user_id: sessionStorage.getItem('user_ID'), //用户ID
                        group_id: this.$route.query.group_id,
                        order_id:this.$route.query.order_id,
                        goods: JSON.stringify(this.goodsData), //将要购买的商品 二维数组
                        // buyType: this.$route.params.id, //2:为立即购买型 1：为购物车购买
                        price_sum: Number(this.data.total_price) + Number(this.freight), //运费计算后的总金额
                        // invoice: JSON.stringify(this.$store.state.invoice_switch), //发票信息二维数组
                        // translate: this.invoice_status, //是否需要发票 1为需要 0为不需要
                        address_id: this.rec_address.id, //收货地址ID
                        remarks: this.message, //留言
                        shipping_monery: this.freight, //运费
                        gcheck: this.gcheck, //验证重复提交
                    })).then((res) => {
                        this.status = false;
                        if (res.data.status == 1) {
                            let price = Number(this.data.total_price) + Number(this.freight);
                            this.$router.push({
                                path: '/groupPayment',
                                query: {
                                    price: price,
                                    order_id: res.data.data,
                                    type: 1
                                }
                            });
                        } else if (res.data.status == 3) {
                            Toast({
                                message: '请勿重复提交',
                                position: 'middle',
                                duration: 800
                            });
                        } else {
                            Toast({
                                message: res.data.msg,
                                position: 'middle',
                                duration: 800
                            });
                        }
                    }).catch((err) => {
                        console.log(err);
                    });
    
                } else {
                    Toast('正在创建订单，请稍等');
                }
    
            },
            tolink(to) {
                this.$store.state.fit = false;
                sessionStorage.setItem('groupInfo', JSON.stringify(this.$route.query));
                this.$router.push({
                    name: to,
                    params: {
                        status: 3
                    }
                });
            },
    
        },
        watch: {
            message() {
                if (this.message.length > 45) {
                    Toast('留言不能超过45字！');
                    this.message = this.message.substring(0, 45);
                }
            }
        },
        mounted() {
            document.body.scrollTop = 0;
            document.body.style.overflowY = "auto";
        },
        destroyed() {
            this.scrollWatch = false;
        },
        components: {
            orderHeader,
            Shopsn
        }
    }
</script>

<style lang="less" scoped>
    .mint-popup-bottom {
        width: 100%;
    }
    
    .order-wrap {
        background: #f1f1f1;
        .inf-header {
            width: 7.1rem;
            height: 1.64rem;
            padding: 0 .2rem;
            background: #fff;
            position: relative;
            .status {
                font-size: .32rem;
                color: #666;
                line-height: 1.64rem;
            }
            .inf-name {
                padding: .3rem 0;
                color: #282828;
                .name {
                    font-size: .36rem;
                    padding-left: .44rem;
                    position: relative;
                    span {
                        position: absolute;
                        top: 50%;
                        left: 0;
                        width: .28rem;
                        height: .41rem;
                        background: url(../../assets/userIcon.png) no-repeat;
                        background-size: 100% 100%;
                        margin-top: -.205rem;
                    }
                }
                .phone {
                    font-size: .36rem;
                    padding-left: .38rem;
                    position: relative;
                    span {
                        position: absolute;
                        left: 0;
                        top: 50%;
                        margin-top: -.17rem;
                        width: .24rem;
                        height: .34rem;
                        background: url(../../assets/phone.png) no-repeat;
                        background-size: 100% 100%;
                    }
                }
            }
            .address {
                width: 6.4rem;
                height: .3rem;
                display: block;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: .28rem;
                color: #999;
                line-height: .32rem;
                position: relative;
            }
            .btn-right {
                width: .18rem;
                height: .3rem;
                position: absolute;
                top: .9rem;
                right: .2rem;
                background: url(../../assets/btn-right.png) no-repeat;
                background-size: 100% 100%;
            }
        }
        .bottom-bg {
            width: 100%;
            margin-bottom: .2rem;
            img {
                width: 100%;
            }
        }
        .mark-wrap {
            margin: .2rem 0;
            background: #fff;
            .send_address {
                padding: .2rem;
                font-size: .3rem;
            }
            li {
                padding: .25rem .2rem;
                border-bottom: 1px solid #dfdfdd;
                height: 1.55rem;
                position: relative;
                img {
                    width: 1.55rem;
                    height: 1.55rem;
                }
                .delete {
                    width: 1.2rem;
                    height: 100%;
                    background: #f9781e;
                    position: absolute;
                    right: 0;
                    top: 0;
                    color: #fff;
                    text-align: center;
                    .icon {
                        width: .51rem;
                        height: .51rem;
                        background: url(../../assets/delete.png) no-repeat;
                        background-size: 100% 100%;
                        margin: .55rem auto .2rem;
                    }
                    .text {
                        font-size: .24rem;
                    }
                }
                .pull-right {
                    padding-left: .2rem;
                    .text {
                        width: 4.7rem;
                        font-size: .24rem;
                        color: #333;
                        line-height: .32rem;
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 2;
                        overflow: hidden;
                    }
                    .price-wrap {
                        padding-top: .4rem;
                        width: 5rem;
                        .price {
                            font-size: .26rem;
                            color: #e02828;
                            span {
                                font-size: .38rem;
                            }
                        }
                        .number {
                            font-size: .32rem;
                            color: #333;
                        }
                    }
                }
            }
        }
        .dist-wrap {
            width: 7.1rem;
            padding: 0 .2rem;
            background: #fff;
            .hd {
                height: 1.1rem;
                line-height: 1.1rem;
                border-bottom: 1px solid #d1d1d1;
                background: url(../../assets/btn-right.png) no-repeat 6.9rem center;
                background-size: .14rem .24rem;
                padding-right: .3rem;
                box-sizing: border-box;
                .title {
                    font-size: .25rem;
                    color: #777;
                }
                .busi {
                    font-size: .25rem;
                    color: #999;
                }
            }
            .hd.active {
                background: #fff;
            }
            .dd {
                margin-bottom: .2rem;
                .title {
                    padding: .3rem 0;
                    font-size: .25rem;
                    color: #777;
                }
                textarea {
                    border: none;
                    resize: none;
                    width: 7.1rem;
                    height: .94rem;
                    background: #f1f1f1;
                    text-indent: .2rem;
                    padding-top: .2rem;
                    outline: none;
                    font-size: .24rem;
                    color: #333;
                    -webkit-user-select: auto;
                }
                .ind {
                    text-align: right;
                    padding: .48rem .2rem .32rem;
                    font-size: .26rem;
                    color: #333;
                    span {
                        font-size: .26rem;
                        color: #f23030;
                    }
                }
            }
        }
        .footer-wrap {
            height: 1rem;
            width: 100%;
            .footer {
                position: fixed;
                bottom: 0;
                left: 0;
                width: 100%;
                height: 1rem;
                background: #fff;
                box-sizing: border-box;
                border-top: 1px solid #ccc;
                .btn {
                    width: 2.5rem;
                    height: 1rem;
                    color: #fff;
                    border: none;
                    background: #ed3851;
                    font-size: .36rem;
                }
                .money {
                    line-height: 1rem;
                    font-size: .3rem;
                    color: #757575;
                    padding-right: .3rem;
                    .price {
                        font-size: .3rem;
                        color: #ed3851;
                        span {
                            font-size: .36rem;
                            font-weight: bold;
                        }
                    }
                }
            }
        }
        .price-set-wrap {
            padding: .2rem;
            background: #fff;
            .price {
                height: .6rem;
                line-height: .6rem;
                span.fl {
                    font-size: .25rem;
                    color: #777;
                }
                span.fr {
                    font-size: .28rem;
                    overflow: hidden;
                    height: 100%;
                    i {
                        font-style: normal;
                        font-size: .28rem;
                    }
                }
                .price_color {
                    color: #ed3851;
                }
            }
        }
    }
</style>