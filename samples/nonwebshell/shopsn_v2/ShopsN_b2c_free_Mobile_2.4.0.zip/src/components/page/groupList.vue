<template>
  <div class="groupbuying_goods">
    <div v-title data-title="拼团商品">拼团商品</div>
    <pr-header :text="title" :sw="sw"></pr-header>
    <div class="groupbuying_list">
      <ul class="groupbuying_item">
        <li class="groupbuying_col" v-for="(item,index) in groupData" :key="index">
          <a href="javascript:;" @click="toLink(item.id)">
            <div class="groupbuying_img">
              <img v-lazy="URL + item.img" alt="">
            </div>
            <div class="groupbuying_info">
              <div class="groupbuying_name">
                {{item.title}}
              </div>
              <div class="groupbuying_tuan_info">
                <div class="groupbuying_tuan_num">
                  {{item.group_person_num}}人团 ￥<span>{{item.price.substring(0,item.price.length-3)}}</span>{{item.price.substring(item.price.length-3,item.price.length)}}
                </div>
                <div class="groupbuying_tuan_del">{{item.price_market}}</div>
                <div class="groupbuying_tuan_btn">去开团</div>
              </div>
            </div>
          </a>
        </li>
      </ul>
      <div class="comm-null" v-if="no_data_sw">
        <div class="con-wrap text-center">
          <img src="../../assets/null_com.png">
          <p>暂无团购商品</p>
        </div>
      </div>
      <div class="up-warp" v-show="load_show">
        <p class="rotate"></p>
        <p class="load-title">加载中..</p>
      </div>
      <div class="no-data" v-show="sliding_data_sw">暂无更多数据~</div>
    </div>
    <div class="load-wrap" v-show="load_wrap" @touchmove.prevent>
      <mt-spinner type="triple-bounce" color="rgb(38, 162, 255)"></mt-spinner>
    </div>
    <to-Top></to-Top>
    <foot-nav></foot-nav>
  </div>
</template>

<script>
  import PrHeader from './children/shop_header.vue';
  import toTop from './children/toTop.vue';
  import footNav from '../footer/footer.vue';
  import {
    Popup,
    Toast,
    MessageBox
  } from 'mint-ui';
  import qs from 'qs';
  export default {
    name: 'groupList',
    data() {
      return {
        sw: 1,
        groupData: [],
        title: '拼团商品',
        load_wrap: false,
        buy_price: '9.80',
        no_data_sw: false, //第一次没数据时样式的开关
        load_show: true, //加载动画开关
        sliding_data_sw: false, //滑动时没数据时样式的开关
        slide_switch: false, //避免多次请求开关
        roll_switch: true, //是否禁止滑动请求
        page: 1,
        position: false, //保存的位置只赋一次值
      }
    },
    updated() {
      this.$nextTick(function() {
        this.position = this.$store.state.groupScrollY ? false : true;
        if (this.position === true) return;
        document.body.scrollTop = this.$store.state.groupScrollY;
      })
    },
    beforeRouteLeave(to, from, next) {
      let position = this.getScrollTop(); //记录离开页面的位置
      if (position == null) position = 0
      this.$store.state.groupData = this.groupData;
      this.$store.state.groupScrollY = position; //离开路由时把位置存起来
      next()
    },
    created() {
      if (this.$store.state.groupData.length > 0) {
        this.groupData = this.$store.state.groupData;
        this.load_show = false;
      } else {
        this.getGroup();
      }
    },
    mounted() {
      window.addEventListener('scroll', this.getDataList);
    },
    destroyed() {
      window.removeEventListener('scroll', this.getDataList);
    },
    methods: {
      toLink(id) {
        if (this.slide_switch == true) return;
        this.$router.push({
          path: '/groupProduct',
          query: {
            id: id
          }
        })
      },
      getDataList() {
        if (document.body.scrollTop + window.innerHeight >= document.documentElement.scrollHeight) {
          if (this.roll_switch == false) { //禁止滑动开关
            return;
          } else {
            this.load_show = true;
          };
          //滑动开关避免多次滑动请求
          if (this.slide_switch == false) {
            this.slide_switch = true;
            this.page++;
            this.getGroup();
          }
  
        }
      },
      //请求成功后的操作
      returnOperation(data) {
        this.load_show = true;
        //第一次获取数据如果数据没铺满屏幕 不再触发滚动
        if (data.length < 10 && this.page == 1) {
          this.load_show = false; //滑动动画隐藏
          this.roll_switch = false; //禁止滚动
        }
        for (let index = 0; index < data.length; index++) {
          this.groupData.push(data[index]);
        }
      },
      getGroup() {
        this.axios.post(API_URL + 'Home/Group/index', qs.stringify({
              app_user_id: sessionStorage.getItem('user_ID'),
            page: this.page
        })).then((res) => {
          this.$store.state.groupScrollY = '';
          if (res.data.status == 1) {
            this.returnOperation(res.data.data);
          } else if (res.data.status == 0 && this.page == 1) {
            this.no_data_sw = true;
            this.sliding_data_sw = false;
            this.load_show = false;
            this.roll_switch = false;
          } else {
            this.load_show = false;
            this.sliding_data_sw = true;
            this.roll_switch = false;
          }
          this.slide_switch = false;
        }).catch((err) => {
          console.log(err);
        })
  
      },
      getScrollTop() { //获取滚动条
        var scroll_top = 0;
        if (document.documentElement && document.documentElement.scrollTop) {
          scroll_top = document.documentElement.scrollTop;
        } else if (document.body) {
          scroll_top = document.body.scrollTop;
        }
        return scroll_top;
      },
    },
    components: {
      PrHeader,
      toTop,
      footNav
    }
  }
</script>

<style lang="less" scoped>
  .groupbuying_goods {
    background: #fff;
    .groupbuying_list {
      .groupbuying_item {
        width: 7.1rem;
        margin: 0 auto;
        overflow: hidden;
        .groupbuying_col {
          width: 3.5rem;
          display: inline-block;
          margin-right: 0.1rem;
          margin-bottom: 0.2rem;
          border-radius: 8px;
          vertical-align: top;
          overflow: hidden;
          background-color: #ffffff;
          .groupbuying_img {
            width: 3.5rem;
            height: 3.5rem;
            img {
              width: 100%;
              height: 100%;
            }
          }
          .groupbuying_info {
            width: 3.2rem;
            margin: 0.2rem auto 0;
            position: relative;
            .groupbuying_name {
              font-size: .24rem;
              min-height: .68rem;
              color: #000000;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              text-overflow: ellipsis;
              overflow: hidden;
              margin-bottom: .34rem;
            }
            .groupbuying_tuan_info {
              .groupbuying_tuan_num {
                color: #ed3851;
                font-size: .24rem;
                span {
                  font-size: .32rem;
                }
              }
              .groupbuying_tuan_del {
                font-size: .24rem;
                color: #aaaaaa;
                margin-left: .16rem;
                text-decoration: line-through;
              }
              .groupbuying_tuan_btn {
                width: 1.16rem;
                height: .5rem;
                border-radius: 50px;
                background-color: #ed3851;
                color: #ffffff;
                text-align: center;
                line-height: .48rem;
                position: absolute;
                right: 0;
                bottom: .1rem;
                font-size: .28rem;
              }
            }
          }
        }
        .groupbuying_col:nth-of-type(2n+2) {
          margin-right: 0;
        }
      }
      .comm-null {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: #fff;
        padding-top: 2.1rem;
        p {
          font-size: .28rem;
          color: #666;
          padding-top: .2rem;
        }
      }
      .up-warp {
        height: .5rem;
        padding: .3rem 0;
        text-align: center;
        p {
          display: inline-block;
          vertical-align: middle;
        }
        .rotate {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          border: 1px solid gray;
          margin-right: 6px;
          border-bottom-color: transparent;
        }
        .rotate {
          -webkit-animation: rotate .6s linear infinite;
          animation: rotate .6s linear infinite
        }
        @-webkit-keyframes rotate {
          0% {
            -webkit-transform: rotate(0deg)
          }
          100% {
            -webkit-transform: rotate(360deg)
          }
        }
        @keyframes rotate {
          0% {
            transform: rotate(0deg)
          }
          100% {
            transform: rotate(360deg)
          }
        }
        .load-title {
          font-size: 12px;
          color: gray;
        }
      }
      .no-data {
        background-color: #fff;
        height: .5rem;
        padding: .3rem 0;
        text-align: center;
        font-size: 12px;
        color: gray;
      }
    }
  }
</style>