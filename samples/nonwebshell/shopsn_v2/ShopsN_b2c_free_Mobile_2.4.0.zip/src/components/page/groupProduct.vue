<template>
  <div class="product">
    <div v-title data-title="商品详情">商品详情</div>
    <pr-header :text="title" :sw="sw"></pr-header>
    <mt-swipe :auto="0">
      <mt-swipe-item v-for="(item,index) in groupDetail.goodsImg" :key="index">
        <img v-lazy="URL + item.pic_url">
      </mt-swipe-item>
    </mt-swipe>
    <div class="secKill_region">
      <div class="detail_decoration" v-if="second">
        <div class="secKill_box">
          <div class="secKill_info fl">
            <span class="tag">
              {{goodsDetail.group_person_num}}人拼
            </span>
            <div class="secKill_price">
              <span class="price">
                ¥ <em>{{goodsDetail.price.substring(0,goodsDetail.price.length-3)}}</em>{{goodsDetail.price.substring(goodsDetail.price.length-3,goodsDetail.price.length)}}</span><span class="original_price">¥{{goodsDetail.price_market}}</span>
            </div>
            <div class="secKill_countdown fl">
              <p class="countdown_text fl">距拼购结束还剩：</p>
              <p class="countdown_nums fl">
                <span class="box">{{day}}</span>天<span class="box">{{hour}}</span>:<span class="box">{{Minute}}</span>:<span class="box">{{second}}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="buy_area">
        <p class="fn_goods_name">
          <span v-if="$store.state.commodity_data.goods_marking == i" class="mark" v-for="(m,i) in mark" :key="m.id">{{m}}</span> {{goodsDetail.title}}
        </p>
      </div>
    </div>
    <!-- <div class="selected" @click="theSon">已选<span class="number">数量&nbsp;{{$store.state.commodity_val}}</span><span class="btn-right"></span></div> -->
    <!--<div class="gui clearfix specifications" v-for="(item,index) in spec_title" :key="item.id">-->
      <!--<p>{{item.name}}</p>-->
      <!--<div class="roll" ref="boxHeight">-->
        <!--<div class="roll_content">-->
          <!--<span :data-id="data.id" :data-spec-id="data.spec_id" v-if="item.id == data.spec_id" v-for="(data,i) in guigedata.spec.spec_children" :key="data.id" @click="addClass(index,$event)" :class="{active: guigedata.goods[specKey].key.indexOf(data.id)>-1}">{{data.item}}</span>-->
        <!--</div>-->
      <!--</div>-->
  <!---->
    <!--</div>-->
    <div class="addSub clearfix">
      <span class="pull-left fl">数量</span>
      <div class="pull-right fr clearfix">
        <!-- <span class="stock fl">库存：{{goodsDetail.goods_num}}件</span> -->
        <div class="input-main fl clearfix">
          <button disabled class="fl" @click="reduce">-</button>
          <input disabled type="tel" class="fl" v-model="commodity_val" @change="min">
          <button disabled class="fl" @click="plusGoods">+</button>
        </div>
      </div>
    </div>
    <div class="picture_details">
      <div class="title">
        <span class="title fl">图文详情</span>
      </div>
      <div class="list-img-wrap" v-html="goodsDetail.detail"></div>
    </div>
    <!-- <div class="prompt" @click="toTab">点击查看更多商品信息</div> -->
    <!-- <detail-option :text="text"></detail-option> -->
    <foot-btn :price="goodsDetail" :state="sonState" :tuanInfo="tuanInfo" :data="$store.state.commodity_data"></foot-btn>
    <div class="load-wrap" v-show="load_wrap" @touchmove.prevent>
      <mt-spinner type="triple-bounce" color="rgb(38, 162, 255)"></mt-spinner>
    </div>
  </div>
</template>

<script>
  import countDown from '../home/children/children/countDown';
  import PrHeader from './children/shop_header.vue';
  import FootBtn from './children/footBtn.vue';
  import {
    Popup,
    Toast,
    MessageBox
  } from 'mint-ui';
  import detailOption from './children/detailOptions.vue';
  import qs from 'qs';
  
  export default {
    name: 'groupProduct',
    data() {
      return {
        mark: {},
        groupDetail:{},
        goodsDetail:{},
        tuanInfo:[],
        commodity_val:1,
        //是否显示状态条
        showIndicators: true,
        //初始轮播切换索引
        defaultIndex: 0,
        //轮播是否循环播放
        continuous: true,
        number: 1,
        conItem: {
          title: '猜你喜欢'
        },
        scrollWatch: true,
        topStatus: '',
        loadTop: {},
        sonState: true,
        data: '',
        title: '商品详情',
        dataLeave: '',
        load_wrap: true,
        endTime: '',
        guigedata: '',
        spec_title: '',
        specKey: this.$route.params.id,
        sw: 1,
        shares: null,
        // url:window.location.hash
        postersShow: false,
        day:'',
        hour: '',
        Minute: '',
        second: '',
        isStart: false
      }
    },
    methods: {
      getMark() {
        this.axios({
          url: API_URL + 'Home/Index/getGoodsMarking',
          method: 'get',
        }).then((res) => {
          this.mark = res.data.data;
        }).catch((err) => {
          console.log(err);
        });
      },
      //处理倒计时
      processingTime() {
        let self = this;
        let now_Time = this.goodsDetail.time;
        let end_Time = this.goodsDetail.end_time;
        let timer = setInterval(function() {
          let t = 0;
          let now = new Date(now_Time * 1000);
          let end = new Date(end_Time * 1000);
          if (now < end) {
            t = end.getTime() - now.getTime();
          }
          if (t > 0) {
            let day = Math.floor(t/86400000);
            let hour = Math.floor((t / 3600000)%24);
            let min = Math.floor((t / 60000) % 60);
            let sec = Math.floor((t / 1000) % 60);
            day = day < 10 ? "0" + day : day;
            hour = hour < 10 ? "0" + hour : hour;
            min = min < 10 ? "0" + min : min;
            sec = sec < 10 ? "0" + sec : sec;
            self.day =  `${day}`;
            self.hour = `${hour}`;
            self.Minute = `${min}`;
            self.second = `${sec}`;
          } else {
            clearInterval(timer);
            self.day =  `00`;
            self.hour = `00`;
            self.Minute = `00`;
            self.second = `00`;
            this.$store.commit('buy_text', '活动已结束');
          }
          now_Time += 1;
        }, 1000);
      },
      ax() {
          this.axios.post(API_URL + 'Home/Group/groupDetail', qs.stringify({
              id: this.$route.query.id,
              order_id:this.$route.query.order_id,
              app_user_id: sessionStorage.getItem('user_ID')
          })).then((res) => {
              if(res.data.status){
                  this.groupDetail = res.data.data;
                  this.goodsDetail = res.data.data.groupGoodsDetail;
                  this.tuanInfo = res.data.data.showOrderData;
                  this.processingTime();
              }else{
                  this.$router.push('/groupList');
              }
              this.load_wrap = false;
        }).catch((err) => {
          console.log(err);
        });
      },
      reduce() {
        if (this.$store.state.commodity_val <= 1) return;
        this.$store.state.commodity_val--;
      },
      plusGoods() {
        if (this.$store.state.commodity_val >= this.$store.state.commodity_data.minStock) return;
        this.$store.state.commodity_val++;
      },
      min() {
        let val = parseInt(this.$store.state.commodity_val);
        let reg = /(^[1-9]([0-9]*)$|^[0-9]$)/;
        if (!reg.test(this.$store.state.commodity_val)) {
          this.$store.state.commodity_val = 1
        }
        if (val >= this.$store.state.commodity_data.minStock) this.$store.state.commodity_val = this.$store.state.commodity_data.minStock;
      },
    },
    created() {
      sessionStorage.removeItem('goods_id');
      this.$store.state.link_id = this.$route.params.id;
      this.$store.commit('clear_data', this.$store.state.commodity_data);
      this.$store.commit('buy_text', '去开团');
      this.getMark();
      this.ax();
    },
    mounted() {
      document.body.scrollTop = 0;
      this.$store.commit('value', this.$store.state.commodity_val);
      this.$store.commit('shops_switch', this.$store.state.const_join);
    },
    destroyed() {
      this.scrollWatch = false;
    },
    components: {
      PrHeader,
      FootBtn,
      detailOption,
      countDown
    }
  }
</script>

<style>
  .mint-swipe-indicator.is-active {
    background: #a1410b;
  }
  
  .list-img-wrap img {
    width: 100%!important;
  }
  
  .tost_z_index {
    z-index: 10000;
    top: 55%!important;
  }
</style>

<style lang="less" scoped>
  .product {
    background: #fff;
  }
  
  .mark {
    position: relative;
    padding: 0 .08rem;
    display: inline-block;
    color: #f81919;
    line-height: normal;
    font-size: .24rem;
    vertical-align: middle;
    margin-top: -3px;
  }
  
  .mark::after {
    content: "";
    display: block;
    border: 1px solid #f81919;
    border-radius: 25px;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    pointer-events: none;
  }
  
  @media only screen and (-webkit-min-device-pixel-ratio: 2) {
    .mark::after {
      right: -100%;
      bottom: -100%;
      -webkit-transform: scale(.5);
      -webkit-transform-origin: 0 0;
    }
  }
  
  .secKill_region {
    .detail_decoration {
      height: 1rem;
      color: #fff;
      .secKill_box {
        overflow: hidden;
        .secKill_info {
          display: -webkit-box;
          display: -webkit-flex;
          display: flex;
          -webkit-box-align: center;
          -webkit-align-items: center;
          align-items: center;
          width: 100%;
          height: 100%;
          position: relative;
          background: -webkit-linear-gradient(left, #ef3923 5%, #fdad5e 95%);
          background: -o-linear-gradient(left, #ef3923 5%, #fdad5e 95%);
          background: -moz-linear-gradient(left, #ef3923 5%, #fdad5e 95%);
          background: linear-gradient(90deg, #ef3923 5%, #fdad5e 95%);
          .tag {
            white-space: nowrap;
            vertical-align: middle;
            position: relative;
            display: inline-block;
            font-size: 10px;
            height: 12px;
            line-height: 12px;
            color: #fff;
            padding: 1px 1px 1px 4px;
            margin: 0 6.5px 2px 25px;
            border: 1px solid #fff;
            border-left: unset;
            border-radius: 2px;
          }
          .tag:before {
            content: "";
            position: absolute;
            left: -15px;
            top: -1px;
            width: 16px;
            height: 16px;
            background: url(../../assets/usertx.png) no-repeat;
            background-size: 100%;
          }
          .secKill_price {
            overflow: hidden;
            display: inline-block;
            vertical-align: middle;
            white-space: normal;
            .price {
              display: inline-block;
              line-height: 1;
              height: 28px;
              margin-right: 4px;
              em {
                font-style: normal;
                font-size: .52rem;
                font-weight: 700;
              }
            }
            .original_price {
              display: inline-block;
              line-height: 1;
              opacity: .6;
              letter-spacing: 0;
              margin-top: -3px;
              text-decoration: line-through;
            }
          }
          .secKill_countdown {
            position: absolute;
            right: 0;
            top: 0;
            color: #ef3d24;
            font-weight: 400;
            width: 30%;
            height: 100%;
            text-align: center;
            .countdown_text {
              font-weight: 700;
              margin: .15rem 0 .08rem;
            }
            .countdown_nums {
              line-height: .42rem;
              .box {
                width: .38rem;
                height: .42rem;
                border-radius: 6px;
                margin: 0 .03rem;
                display: inline-block;
                color: #fff;
                background-color: #ef3d24;
              }
            }
          }
        }
      }
    }
    .buy_area {
      padding: 0 .2rem;
      position: relative;
      .fn_goods_name {
        font-size: .3rem;
        min-height: 1rem;
        color: #333;
        font-weight: 600;
        padding: .1rem 0;
        padding-right: 1.5rem;
        line-height: .5rem;
      }
    }
  }
  
  .selected {
    padding: 0 .2rem;
    height: 1.1rem;
    line-height: 1.1rem;
    font-size: .25rem;
    color: #777;
    position: relative;
    background: #fff;
    border-top: 1px solid #f1f1f1;
    .number {
      font-size: .3rem;
      color: #333;
      padding-left: .55rem;
    }
    .btn-right {
      position: absolute;
      right: .3rem;
      top: 50%;
      margin-top: -.12rem;
      width: .14rem;
      height: .24rem;
      background: url(../../assets/btn-right.png) no-repeat;
      background-size: 100% 100%;
    }
  }
  .addSub {
    height: 1.3rem;
    padding: 0 .2rem;
    border-top: 1px solid #dfe3e4;
    line-height: 1.3rem;
    .pull-left {
      font-size: .32rem;
      color: #757575;
    }
    .pull-right {
      .stock {
        font-size: .24rem;
        color: #aeadad;
      }
      .input-main {
        width: 2.36rem;
        height: .79rem;
        border: 1px solid #dfdfdd;
        border-radius: 5px;
        margin-top: .25rem;
        margin-left: .2rem;
        overflow: hidden;
        line-height: .79rem;
        button {
          width: .7rem;
          border: none;
          background: #fff;
          color: #757575;
          font-size: .5rem;
          line-height: .79rem;
          outline: none;
          height: 100%;
          background: #fff;
        }
        button:active {
          background: #ff7200;
          color: #fff;
        }
        input {
          width: .95rem;
          border: none;
          height: 100%;
          border-left: 1px solid #dfdfdd;
          border-right: 1px solid #dfdfdd;
          text-align: center;
          font-size: .4rem;
          color: #757575;
          background: #fff;
        }
      }
    }
  }
  
  .mint-swipe {
    height: 7.3rem;
    .mint-swipe-items-wrap {
      div {
        width: 100%;
        height: 7.5rem;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }
  
  .prompt {
    width: 100%;
    height: .9rem;
    background: #f1f1f1;
    line-height: .9rem;
    text-align: center;
    font-size: .26rem;
    color: #999;
  }
  
  .picture_details {
    .title {
      height: .8rem;
      line-height: .8rem;
      font-size: .25rem;
      color: #777;
      position: relative;
      background: #fff;
      border-top: 1px solid #f1f1f1;
      span {
        width: 2rem;
        text-align: center;
        color: #333;
        font-size: .3rem;
        border-bottom: 2px solid #ed3851;
      }
    }
    .list-img-wrap {
      padding-top: .3rem;
      padding-bottom: 2rem;
    }
  }
  
  #dcontent {
    .heading {
      display: none;
    }
    .sharehref {
      display: none;
    }
  }
  
  .mint-popup-bottom {
    width: 100%;
  }
  
  .main {
    width: 100%;
    max-height: 9.5rem;
    background-color: #fff;
    .header {
      position: relative;
      height: .92rem;
      line-height: .92rem;
      padding-left: .2rem;
      font-size: .32rem;
      color: #333;
      background-color: #f7f7f7;
      .close {
        position: absolute;
        top: 0;
        right: 0;
        width: 1rem;
        height: .92rem;
      }
      .close:after {
        content: "";
        position: absolute;
        top: .32rem;
        right: .2rem;
        width: .3rem;
        height: .3rem;
        background: url(../../assets/close-i.png) no-repeat 50%;
        background-size: 100%;
      }
    }
    .content {
      max-height: 8.58rem;
      overflow: auto;
      padding: 0 .2rem;
      -webkit-overflow-scrolling: touch;
      .coupon_list {
        .coupon {
          color: #ed3851;
          margin-bottom: .3rem;
          padding: .14rem .2rem .2rem;
          border-top: .12rem solid currentColor;
          box-shadow: 0 0 .12rem 0 rgba(0, 0, 0, .1);
          border-radius: .12rem;
          .coupon_main {
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            min-height: 1.24rem;
            .price-box {
              width: 2.2rem;
              margin-right: .2rem;
              line-height: 1;
              text-align: center;
              display: -webkit-box;
              display: -webkit-flex;
              display: flex;
              -webkit-box-orient: vertical;
              -webkit-box-direction: normal;
              -webkit-flex-direction: column;
              flex-direction: column;
              -webkit-box-pack: center;
              -webkit-justify-content: center;
              justify-content: center;
              .view_price {
                line-height: 1;
                i {
                  font-size: .28rem;
                  display: inline-block;
                  vertical-align: top;
                  margin-top: .06rem;
                  font-style: normal;
                }
                strong {
                  font-weight: 700;
                  font-size: .7rem;
                  position: relative;
                  top: .02rem;
                  left: -.1rem;
                  line-height: 100%;
                }
              }
              .view_des {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-size: .24rem;
                margin-top: .1rem;
              }
            }
            .coupon_info {
              -webkit-box-flex: 1;
              -webkit-flex: 1;
              flex: 1;
              position: relative;
              .coupon_info_text {
                height: 36px;
                line-height: 18px;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                font-size: .24rem;
                color: #666;
                .coupon_info_type {
                  font-style: normal;
                  background-color: #ed3851;
                  color: #fff;
                  font-size: 12px;
                  display: inline-block;
                  padding: 0 6px 0 12px;
                  height: 14px;
                  margin-right: 4px;
                  line-height: 14px;
                  position: relative;
                  border-radius: 0 3px 3px 0;
                }
                .coupon_info_type:before {
                  position: absolute;
                  z-index: 1;
                  content: "";
                  width: 0;
                  top: 0;
                  left: -7px;
                  height: 0;
                  border-top: 7px solid #fff;
                  border-right: 7px solid transparent;
                  border-bottom: 7px solid #fff;
                  border-left: 7px solid #fff;
                }
                .coupon_info_type:after {
                  content: ".";
                  position: absolute;
                  color: #fff;
                  left: 5px;
                  top: -6px;
                  font-size: 20px;
                }
              }
              .coupon_info_btn {
                position: absolute;
                right: 0;
                bottom: 0;
                width: 1.36rem;
                height: .4rem;
                line-height: .4rem;
                text-align: center;
                border-radius: .2rem;
                box-sizing: border-box;
                z-index: 2;
                background-color: #ed3851;
                color: #fff;
                font-size: .24rem;
              }
              .disabled {
                border: .02rem solid #999;
                background-color: #fff!important;
                color: #999;
              }
              .coupon_info_date {
                position: absolute;
                left: 0;
                bottom: 0;
                padding-right: 1.36rem;
                box-sizing: border-box;
                width: 100%;
                line-height: .4rem;
                font-size: .2rem;
                color: #999;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
              }
            }
          }
        }
      }
    }
  }
</style>