<template>
  <div>
    <order-header :text="order_title" :search="search"></order-header>
    <div class="nav-wrap">
      <ul class="nav">
        <li class="fl" v-for="(name,index) in navList" :key="index" :class="{active:status == name.state}" @click="addNav(name)"><span>{{name.title}}</span></li>
      </ul>
    </div>
    <div class="whole-wrap">
      <div v-title :data-title="$store.state.order_title" v-if="$store.state.order_title">{{$store.state.order_title}}</div>
      <div class="order-wrap" ref="order_wrap">
        <div class="order-list" v-for="(item,index) in groupData" :key="index">
          <div class="hd clearfix">
            <span class="title fl">2天聚清</span>
          </div>
          <div class="describe clearfix" @click="toGoods(item.group_id)">
            <img :src="URL + item.img" class="fl">
            <div class="fl words">
              <p class="text">{{item.title}}</p>
              <p class="clearfix company">
                <span class="goods_tuan_tag fl">
                                        {{item.group_person_num}}人拼
                                      </span>
                <span class="fl price">￥<span class="em">{{item.price_sum}}</span></span>
              </p>
            </div>
            <!-- <button class="btn" @click="toRouter('/evaluate',item,text)" v-if="item.order_state == '1'">马上评论</button> -->
          </div>
          <div class="commod clearfix">
            <span v-if="item.group_status" class="tuan_btn bg_1" @click="toDetail(item)">拼购详情</span>
            <span v-if="item.group_status == 2 || item.group_status == 3" class="tuan_btn bg_1" @click="toOrder(item)">订单详情</span>
            <span class="tuan_btn bg_2" v-if="item.group_status && item.group_status == 1" @click="toShare(item)">邀请好友</span>
            <span v-if="item.order_status == 0 && !item.group_status" class="tuan_btn bg_2" @click="toPay(item)">去付款</span>
          </div>
        </div>
        <div class="comm-null" v-if="no_data_sw">
          <div class="con-wrap text-center">
            <img src="../../assets/null_com.png">
            <p>暂无团购商品</p>
          </div>
        </div>
        <div class="up-warp" v-show="load_show">
          <p class="rotate"></p>
          <p class="load-title">加载中..</p>
        </div>
        <div class="no-data" v-show="sliding_data_sw">暂无更多数据~</div>
      </div>
    </div>
    <div class="load-wrap" v-show="order_load_wrap" @touchmove.prevent>
      <mt-spinner type="triple-bounce" color="rgb(38, 162, 255)"></mt-spinner>
    </div>
    <!-- 弹框的html -->
    <div id="picture" class="mui-popover mui-popover-action mui-popover-bottom" style="z-index: 99999999">
      <ul class="mui-table-view">
        <li class="mui-table-view-cell">
          <a href="javascript:;" id="saveImg">保存图片</a>
        </li>
      </ul>
      <ul class="mui-table-view">
        <li class="mui-table-view-cell">
          <a href="#picture"><b>取消</b></a>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  import orderHeader from '@/components/page/children/header.vue';
  import qs from 'qs';
  import {
    MessageBox
  } from 'mint-ui';
  export default {
    name: 'groupOrder',
    data() {
      return {
        order_load_wrap: false,
        groupData: [],
        navList: [{
          title: '待付款',
          state: 0
        }, {
          title: '拼团中',
          state: 1
        }, {
          title: '已成功',
          state: 2
        }, {
          title: '已过期',
          state: 3
        }],
          urlImg:'',
        search: true,
        status: 0,
        order_title: '待付款',
        no_data_sw: false, //第一次没数据时样式的开关
        load_show: false, //加载动画开关
        sliding_data_sw: false, //滑动时没数据时样式的开关
        slide_switch: false, //避免多次请求开关
        roll_switch: true, //是否禁止滑动请求
        page: 1
      }
    },
    components: {
      orderHeader
    },
    beforeRouteLeave(to, from, next) {
      MessageBox.close(false);
      $("#middlePopover").hide();
      $(".mui-backdrop.mui-active").css("opacity", "0");
      next();
    },
    created() {
      this.getGroup(this.status);
    },
    mounted() {
      window.addEventListener('scroll', this.getOrderList);
    },
    destroyed() {
      window.removeEventListener('scroll', this.getOrderList);
    },
    methods: {
      //去支付
      toPay(item) {
        this.$router.push({
          path: '/groupPayment',
          query: {
              price: item.price_sum,
              order_id: item.pay_id,
              type: 1
          }
        })
      },
      //分享二维码
      toShare(item) {
        this.axios({
          url: API_URL + 'Home/Group/getSharePicture',
          method: 'get',
          params: {
            app_user_id:sessionStorage.getItem('user_ID'),
            id:item.id,
            group_id:item.group_id
          }
        }).then((res) => {
          MessageBox({
            title: '',
            showConfirmButton: false,
            cancelButtonClass: false,
            message: '<p id="imgsul"><img class="saveImg" style="width:4.5rem; height:6.75rem;margin-bottom:.3rem;" src=' + this.URL + res.data.data + '></p><p>长按保存，分享好友</p>',
          })
          this.publicMethod.savePictures();
  
        }).catch((err) => {
          console.log(err);
        });
      },
      toGoods(id) {
          this.$router.push({
              path: '/groupProduct',
              query: {
                  id: id
              }
          })
      },
      //团购详情
      toDetail(item) {
        this.$router.push({
          path: 'orderGroupDetail',
          query: {
            id:item.id,
            group_id:item.group_id,
            s:1 //订单进入拼购详情
          }
        })
      },
      //订单详情
      toOrder(item) {
        this.$router.push({
          path: 'groupOrderDetail',
          query: {
            order_id:item.id
          }
        })
      },
      getOrderList() {
        if (document.body.scrollTop + window.innerHeight >= document.documentElement.scrollHeight) {
          if (this.roll_switch == false) { //禁止滑动开关
            return;
          } else {
           // this.load_show = true;
          };
          //滑动开关避免多次滑动请求
          if (this.slide_switch == false) {
            this.page++;
            this.getGroup(this.status);
          }
        }
      },
      getGroup(status) {
        this.slide_switch = true;
        this.axios.post(API_URL + 'Home/GroupOrder/index', qs.stringify({
          app_user_id: sessionStorage.getItem('user_ID'),
          status: status,
          page: this.page
        })).then((res) => {
          if (res.data.status == 1) {
            this.returnOperation(res.data.data);
          } else if (res.data.status == 0 && this.page == 1) {
            this.no_data_sw = true;
            this.sliding_data_sw = false;
          //  this.load_show = false;
            this.roll_switch = false;
          } else {
         //   this.load_show = false;
            this.sliding_data_sw = true;
            this.roll_switch = false;
          }
          this.slide_switch = false;
        }).catch((err) => {
          console.log(err);
        })
      },
      //请求成功后的操作
      returnOperation(data) {
        //this.load_show = true;
        //第一次获取数据如果数据没铺满屏幕 不再触发滚动
        if (data.length < 10 && this.page == 1) {
       //   this.load_show = false; //滑动动画隐藏
          this.roll_switch = false; //禁止滚动
        }
        for (let index = 0; index < data.length; index++) {
          this.groupData.push(data[index]);
        }
      },
      initialization() {
        this.no_data_sw = false; //第一次没数据时样式的开关
      //  this.load_show = true; //加载动画开关
        this.sliding_data_sw = false; //滑动时没数据时样式的开关
        this.roll_switch = true; //是否禁止滑动请求
        this.page = 1;
        this.groupData = [];
      },
      addNav(state) {
        if (this.slide_switch == true) return;
        this.initialization();
        this.status = state.state;
        this.order_title = state.title;
        this.getGroup(this.status);
  
      }
    }
  }
</script>

<style lang="less" scoped>
  .mui-popover.mui-popover-action.mui-popover-bottom {
    position: fixed;
  }

  .mui-popover.mui-popover-action {
    bottom: 0;
    width: 100%;
    -webkit-transition: -webkit-transform .3s, opacity .3s;
    transition: transform .3s, opacity .3s;
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
    border-radius: 0;
    background: none;
    -webkit-box-shadow: none;
    box-shadow: none;
  }


  .mui-popover {
    position: absolute;
    z-index: 999;
    display: none;
    width: 280px;
    -webkit-transition: opacity .3s;
    transition: opacity .3s;
    -webkit-transition-property: opacity;
    transition-property: opacity;
    -webkit-transform: none;
    transform: none;
    opacity: 0;
    border-radius: 7px;
    background-color: #f7f7f7;
    -webkit-box-shadow: 0 0 15px rgba(0, 0, 0, .1);
    box-shadow: 0 0 15px rgba(0, 0, 0, .1);
  }
  .nav-wrap {
    width: 100%;
    background: #fff;
    .nav {
      height: .94rem;
      border-bottom: 1px solid #dfdfdd;
      li {
        width: 25%;
        height: 100%;
        text-align: center;
        overflow: hidden;
        box-sizing: border-box;
        span {
          display: block;
          color: #676767;
          font-size: .3rem;
          line-height: .54rem;
          height: .54rem;
          margin: .2rem 0;
          border-right: 1px solid #dfdfdd;
        }
      }
      li:last-child {
        span {
          border: none;
        }
      }
      li.active {
        border-bottom: 3px solid #fd4f4b;
        span {
          color: #ff781a;
        }
      }
    }
  }
  
  .whole-wrap {
    // background: #f1f1f1;
    .order-wrap {
      padding-top: .1rem;
      .order-list {
        background: #fff;
        line-height: .7rem;
        margin-bottom: .2rem;
        .hd {
          margin: 0 .2rem;
          border-bottom: 1px solid #dfdfdd;
          height: .7rem;
          .title {
            font-size: .26rem;
            color: #333;
          }
        }
        .describe {
          margin: 0 .2rem;
          height: 1.46rem;
          padding: .13rem 0;
          border-bottom: 1px solid #dfdfdd;
          position: relative;
          .company {
            padding-top: .2rem;
            padding-left: .2rem;
            line-height: .35rem;
            .goods_tuan_tag {
              color: #ed3851;
              position: relative;
              display: inline-block;
              height: .3rem;
              padding: 0 .04rem 0 .34rem;
              line-height: .3rem;
              font-size: .24rem;
              border-radius: 2px;
              border: 1px solid #ed3851;
              vertical-align: baseline;
            }
            .goods_tuan_tag:before {
              content: "";
              position: absolute;
              top: 0;
              left: 0;
              bottom: 0;
              width: .28rem;
              background: url(../../assets/tx_icon.png)no-repeat #ed3851;
              background-size: 70% 70%;
              background-position: 50% 50%;
            }
            .price {
              color: #ed3851;
              font-size: .24rem;
              font-weight: 700;
              line-height: .3rem;
              .em {
                font-size: .32rem;
                font-weight: 700;
              }
            }
          }
          .btn {
            position: absolute;
            right: 0;
            bottom: .1rem;
            width: 1.5rem;
            height: .5rem;
            border: 1px solid #ff881e;
            background: #fff;
            border-radius: 20px;
            color: #ff881e;
          }
          img {
            width: 1.46rem;
            height: 1.46rem;
          }
          .words {
            width: 5.24rem;
            .text {
              height: .8rem;
              padding: 0 .2rem;
              font-size: .32rem;
              color: #333;
              line-height: .45rem;
              overflow: hidden;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              -webkit-box-orient: vertical;
            }
          }
        }
        .commod {
          position: relative;
          overflow: hidden;
          font-size: 0;
          line-height: normal;
          text-align: right;
          padding: .2rem;
          border-bottom: 1px solid #dfdfdd;
          .tuan_btn {
            display: inline-block;
            height: .5rem;
            line-height: .5rem;
            font-size: .28rem;
            text-align: center;
            border-radius: 25px;
            position: relative;
            margin-left: .2rem;
            width: 2.04rem;
          }
          .bg_1 {
            background-color: #fff;
            color: #333;
            box-shadow: 0 2px 5px rgba(0, 0, 0, .1);
          }
          .bg_2 {
            background-image: -webkit-linear-gradient(left, #ea3e3f, #fe9071);
            color: #fff;
            box-shadow: 0 2px 5px rgba(234, 62, 63, .1);
          }
        }
      }
      .comm-null {
        p {
          font-size: .28rem;
          color: #666;
          padding-top: .2rem;
        }
      }
      .up-warp {
        height: .5rem;
        padding: .3rem 0;
        text-align: center;
        p {
          display: inline-block;
          vertical-align: middle;
        }
        .rotate {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          border: 1px solid gray;
          margin-right: 6px;
          border-bottom-color: transparent;
        }
        .rotate {
          -webkit-animation: rotate .6s linear infinite;
          animation: rotate .6s linear infinite
        }
        @-webkit-keyframes rotate {
          0% {
            -webkit-transform: rotate(0deg)
          }
          100% {
            -webkit-transform: rotate(360deg)
          }
        }
        @keyframes rotate {
          0% {
            transform: rotate(0deg)
          }
          100% {
            transform: rotate(360deg)
          }
        }
        .load-title {
          font-size: 12px;
          color: gray;
        }
      }
      .no-data {
        background-color: #fff;
        height: .5rem;
        padding: .3rem 0;
        text-align: center;
        font-size: 12px;
        color: gray;
      }
    }
  }
</style>