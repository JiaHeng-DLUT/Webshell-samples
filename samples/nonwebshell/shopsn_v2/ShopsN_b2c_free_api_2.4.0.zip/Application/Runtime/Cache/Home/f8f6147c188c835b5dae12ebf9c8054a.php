<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
    <title>Title</title>
    <style>
        *{
            margin:0;
            padding:0;
        }
        .pro-comment .introduce{
            text-align: center;
        }
        .introduce img{
            width: 100%;
        }
    </style>
</head>
<body>
<dl class="pro-comment ">
    <dt class="clearfix">
    </dt>
    <dd class="introduce"><?php echo ($detail); ?></dd>
</dl>
</body>
</html>