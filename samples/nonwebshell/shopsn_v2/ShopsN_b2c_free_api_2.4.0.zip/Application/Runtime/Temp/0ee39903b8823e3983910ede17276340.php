<?php
//000000000000a:1:{i:3385;a:11:{s:8:"goods_id";s:4:"3385";s:11:"goods_price";s:6:"228.00";s:9:"goods_num";i:1;s:11:"good_rebate";s:4:"0.00";s:11:"self_rebate";s:4:"0.00";s:11:"freights_id";s:1:"0";s:6:"weight";s:5:"0.000";s:12:"send_address";s:1:"0";s:7:"ware_id";s:1:"0";s:7:"user_id";s:1:"5";s:8:"space_id";s:4:"2398";}}
?>