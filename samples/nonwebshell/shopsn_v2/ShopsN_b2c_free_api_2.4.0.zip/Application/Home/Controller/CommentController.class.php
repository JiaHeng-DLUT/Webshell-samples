<?php 

namespace Home\Controller;

use Think\Controller;

/**
 * 商品评论 
 */
class CommentController extends CommonController {

}