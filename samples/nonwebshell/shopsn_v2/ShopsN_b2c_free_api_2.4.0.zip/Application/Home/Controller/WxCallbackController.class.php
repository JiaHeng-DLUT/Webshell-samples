<?php
namespace Home\Controller;
/**
 * wechat php test
 */

class WxCallbackController extends CommonController
{

    //增加新用户
    public function addUser($openid,$scene_id){

        if(!$openid){
            return false;
        }
        $id = M('user')->where(['open_id'=>$openid])->getField('id');
        if($id){
            return true;
        }else{
            if((int)$scene_id != 0){
                $p_id = $scene_id;
            }else{
                $scene_id = explode('_',$scene_id);
                $p_id = $scene_id[1];
            }
            $data = [
                'open_id'       =>$openid,
                'create_time'   => time(),
                'user_name'     => $this->getUserName(),
                'p_id'          => $p_id,
            ];
            M('user')->add( $data );
            return true;
        }

    }

    //自动生成用户名
    private function getUserName(){
        $str = 'abcdfghjklmnpqrstwxyz';
        $str2 = 'abcdefghijklmnopqrstuvwxyz';
        $length = strlen($str)-1;
        $length2 = strlen($str2)-1;
        $a=rand(0,$length);
        $b=rand(0,$length2);
        $username=substr($str,$a,1).substr($str2,$b,1).rand(100000,999999);

        $res = M('user')->where(['user_name'=>$username])->find();
        if($res){
            $this->getUserName();
        }else{
            return $username;
        }

    }


}

?>